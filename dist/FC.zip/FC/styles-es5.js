(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["styles"], {
  /***/"./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./src/styles.css":
  /*!*****************************************************************************************************************************************************************!*\
    !*** ./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src??embedded!./src/styles.css ***!
    \*****************************************************************************************************************************************************************/
  /*! no static exports found */
  /***/
  function node_modulesAngularDevkitBuildAngularSrcAngularCliFilesPluginsRawCssLoaderJsNode_modulesPostcssLoaderSrcIndexJsSrcStylesCss(module, exports) {
    module.exports = [[module.i, "/* Cambiar el color de fondo de los botones de navegación */\r\n.mat-horizontal-stepper-header-container .mat-step-header .mat-step-icon-selected {\r\n    background-color: #ffc107; /* Cambia a tu color preferido */\r\n    color: black;\r\n    font-weight: 500;\r\n    font-size: 20px;\r\n    transition: background-color 0.3s, color 0.3s; /* Agrega una transición para suavizar el cambio */\r\n    border-width: 10px;\r\n}\r\n/* Aumentar el tamaño del círculo del paso */\r\n.mat-step-icon {\r\n    color: white;\r\n    width: 50px; /* Ajusta el tamaño del círculo según tus necesidades */\r\n    height: 50px; /* Ajusta el tamaño del círculo según tus necesidades */\r\n    border: 1.5px solid #ffc107; /* Cambia a tu color preferido */\r\n    border-radius: 50%; /* Hace que el círculo sea redondeado */\r\n}\r\n/* Cambiar el color del círculo del paso cuando se hace hover */\r\n.mat-step-header:hover .mat-step-icon {\r\n    background-color: #ffc107; /* Cambia a tu color preferido */\r\n    color: black; /* Cambia el color del ícono */\r\n    font-size: 20px;\r\n    font-weight: 600;\r\n}\r\n/* Cambiar el color del texto de los botones de navegación */\r\n.mat-horizontal-stepper-header-container .mat-step-header .mat-step-label {\r\n    color: white; /* Cambia a tu color preferido */\r\n    font-size: 22px;\r\n    font-family: Tahoma, Geneva, Verdana, sans-serif;\r\n    font-weight: 500;\r\n}\r\n/* Aumentar el grosor y cambiar el estilo de la línea de separación */\r\n.mat-horizontal-stepper-header-container .mat-stepper-horizontal-line {\r\n    border-top: 2px dashed #ffc107; /* Cambia \"your-color\" al color deseado */\r\n    border-radius: 4px; /* Ajusta la curvatura de la línea si lo deseas */\r\n}\r\n/* Cambiar el estilo de la línea de separación cuando está completa a una línea punteada */\r\n.mat-horizontal-stepper-header-container .mat-step-header-completed .mat-stepper-horizontal-line {\r\n    border-top: 3px dashed #4CAF50; /* Cambia \"#4CAF50\" al color deseado para pasos completados */\r\n}\r\n\r\n\r\n  \r\n  \r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9zdHlsZXMuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDJEQUEyRDtBQUMzRDtJQUNJLHlCQUF5QixFQUFFLGdDQUFnQztJQUMzRCxZQUFZO0lBQ1osZ0JBQWdCO0lBQ2hCLGVBQWU7SUFDZiw2Q0FBNkMsRUFBRSxrREFBa0Q7SUFDakcsa0JBQWtCO0FBQ3RCO0FBRUEsNENBQTRDO0FBQzVDO0lBQ0ksWUFBWTtJQUNaLFdBQVcsRUFBRSx1REFBdUQ7SUFDcEUsWUFBWSxFQUFFLHVEQUF1RDtJQUNyRSwyQkFBMkIsRUFBRSxnQ0FBZ0M7SUFDN0Qsa0JBQWtCLEVBQUUsdUNBQXVDO0FBQy9EO0FBRUEsK0RBQStEO0FBQy9EO0lBQ0kseUJBQXlCLEVBQUUsZ0NBQWdDO0lBQzNELFlBQVksRUFBRSw4QkFBOEI7SUFDNUMsZUFBZTtJQUNmLGdCQUFnQjtBQUNwQjtBQUVBLDREQUE0RDtBQUM1RDtJQUNJLFlBQVksRUFBRSxnQ0FBZ0M7SUFDOUMsZUFBZTtJQUNmLGdEQUFnRDtJQUNoRCxnQkFBZ0I7QUFDcEI7QUFFQSxxRUFBcUU7QUFDckU7SUFDSSw4QkFBOEIsRUFBRSx5Q0FBeUM7SUFDekUsa0JBQWtCLEVBQUUsaURBQWlEO0FBQ3pFO0FBRUEsMEZBQTBGO0FBQzFGO0lBQ0ksOEJBQThCLEVBQUUsNkRBQTZEO0FBQ2pHIiwiZmlsZSI6InNyYy9zdHlsZXMuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLyogQ2FtYmlhciBlbCBjb2xvciBkZSBmb25kbyBkZSBsb3MgYm90b25lcyBkZSBuYXZlZ2FjacOzbiAqL1xyXG4ubWF0LWhvcml6b250YWwtc3RlcHBlci1oZWFkZXItY29udGFpbmVyIC5tYXQtc3RlcC1oZWFkZXIgLm1hdC1zdGVwLWljb24tc2VsZWN0ZWQge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmYzEwNzsgLyogQ2FtYmlhIGEgdHUgY29sb3IgcHJlZmVyaWRvICovXHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG4gICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAwLjNzLCBjb2xvciAwLjNzOyAvKiBBZ3JlZ2EgdW5hIHRyYW5zaWNpw7NuIHBhcmEgc3Vhdml6YXIgZWwgY2FtYmlvICovXHJcbiAgICBib3JkZXItd2lkdGg6IDEwcHg7XHJcbn1cclxuXHJcbi8qIEF1bWVudGFyIGVsIHRhbWHDsW8gZGVsIGPDrXJjdWxvIGRlbCBwYXNvICovXHJcbi5tYXQtc3RlcC1pY29uIHtcclxuICAgIGNvbG9yOiB3aGl0ZTtcclxuICAgIHdpZHRoOiA1MHB4OyAvKiBBanVzdGEgZWwgdGFtYcOxbyBkZWwgY8OtcmN1bG8gc2Vnw7puIHR1cyBuZWNlc2lkYWRlcyAqL1xyXG4gICAgaGVpZ2h0OiA1MHB4OyAvKiBBanVzdGEgZWwgdGFtYcOxbyBkZWwgY8OtcmN1bG8gc2Vnw7puIHR1cyBuZWNlc2lkYWRlcyAqL1xyXG4gICAgYm9yZGVyOiAxLjVweCBzb2xpZCAjZmZjMTA3OyAvKiBDYW1iaWEgYSB0dSBjb2xvciBwcmVmZXJpZG8gKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTsgLyogSGFjZSBxdWUgZWwgY8OtcmN1bG8gc2VhIHJlZG9uZGVhZG8gKi9cclxufVxyXG5cclxuLyogQ2FtYmlhciBlbCBjb2xvciBkZWwgY8OtcmN1bG8gZGVsIHBhc28gY3VhbmRvIHNlIGhhY2UgaG92ZXIgKi9cclxuLm1hdC1zdGVwLWhlYWRlcjpob3ZlciAubWF0LXN0ZXAtaWNvbiB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZjMTA3OyAvKiBDYW1iaWEgYSB0dSBjb2xvciBwcmVmZXJpZG8gKi9cclxuICAgIGNvbG9yOiBibGFjazsgLyogQ2FtYmlhIGVsIGNvbG9yIGRlbCDDrWNvbm8gKi9cclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuICAgIFxyXG4vKiBDYW1iaWFyIGVsIGNvbG9yIGRlbCB0ZXh0byBkZSBsb3MgYm90b25lcyBkZSBuYXZlZ2FjacOzbiAqL1xyXG4ubWF0LWhvcml6b250YWwtc3RlcHBlci1oZWFkZXItY29udGFpbmVyIC5tYXQtc3RlcC1oZWFkZXIgLm1hdC1zdGVwLWxhYmVsIHtcclxuICAgIGNvbG9yOiB3aGl0ZTsgLyogQ2FtYmlhIGEgdHUgY29sb3IgcHJlZmVyaWRvICovXHJcbiAgICBmb250LXNpemU6IDIycHg7XHJcbiAgICBmb250LWZhbWlseTogVGFob21hLCBHZW5ldmEsIFZlcmRhbmEsIHNhbnMtc2VyaWY7XHJcbiAgICBmb250LXdlaWdodDogNTAwO1xyXG59XHJcblxyXG4vKiBBdW1lbnRhciBlbCBncm9zb3IgeSBjYW1iaWFyIGVsIGVzdGlsbyBkZSBsYSBsw61uZWEgZGUgc2VwYXJhY2nDs24gKi9cclxuLm1hdC1ob3Jpem9udGFsLXN0ZXBwZXItaGVhZGVyLWNvbnRhaW5lciAubWF0LXN0ZXBwZXItaG9yaXpvbnRhbC1saW5lIHtcclxuICAgIGJvcmRlci10b3A6IDJweCBkYXNoZWQgI2ZmYzEwNzsgLyogQ2FtYmlhIFwieW91ci1jb2xvclwiIGFsIGNvbG9yIGRlc2VhZG8gKi9cclxuICAgIGJvcmRlci1yYWRpdXM6IDRweDsgLyogQWp1c3RhIGxhIGN1cnZhdHVyYSBkZSBsYSBsw61uZWEgc2kgbG8gZGVzZWFzICovXHJcbn1cclxuXHJcbi8qIENhbWJpYXIgZWwgZXN0aWxvIGRlIGxhIGzDrW5lYSBkZSBzZXBhcmFjacOzbiBjdWFuZG8gZXN0w6EgY29tcGxldGEgYSB1bmEgbMOtbmVhIHB1bnRlYWRhICovXHJcbi5tYXQtaG9yaXpvbnRhbC1zdGVwcGVyLWhlYWRlci1jb250YWluZXIgLm1hdC1zdGVwLWhlYWRlci1jb21wbGV0ZWQgLm1hdC1zdGVwcGVyLWhvcml6b250YWwtbGluZSB7XHJcbiAgICBib3JkZXItdG9wOiAzcHggZGFzaGVkICM0Q0FGNTA7IC8qIENhbWJpYSBcIiM0Q0FGNTBcIiBhbCBjb2xvciBkZXNlYWRvIHBhcmEgcGFzb3MgY29tcGxldGFkb3MgKi9cclxufVxyXG5cclxuXHJcbiAgXHJcbiAgIl19 */", '', '']];

    /***/
  },

  /***/"./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js":
  /*!****************************************************************************!*\
    !*** ./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js ***!
    \****************************************************************************/
  /*! no static exports found */
  /***/
  function node_modulesStyleLoaderDistRuntimeInjectStylesIntoStyleTagJs(module, exports, __webpack_require__) {
    "use strict";

    var stylesInDom = {};
    var isOldIE = function isOldIE() {
      var memo;
      return function memorize() {
        if (typeof memo === 'undefined') {
          // Test for IE <= 9 as proposed by Browserhacks
          // @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
          // Tests for existence of standard globals is to allow style-loader
          // to operate correctly into non-standard environments
          // @see https://github.com/webpack-contrib/style-loader/issues/177
          memo = Boolean(window && document && document.all && !window.atob);
        }
        return memo;
      };
    }();
    var getTarget = function getTarget() {
      var memo = {};
      return function memorize(target) {
        if (typeof memo[target] === 'undefined') {
          var styleTarget = document.querySelector(target); // Special case to return head of iframe instead of iframe itself

          if (window.HTMLIFrameElement && styleTarget instanceof window.HTMLIFrameElement) {
            try {
              // This will throw an exception if access to iframe is blocked
              // due to cross-origin restrictions
              styleTarget = styleTarget.contentDocument.head;
            } catch (e) {
              // istanbul ignore next
              styleTarget = null;
            }
          }
          memo[target] = styleTarget;
        }
        return memo[target];
      };
    }();
    function listToStyles(list, options) {
      var styles = [];
      var newStyles = {};
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        var id = options.base ? item[0] + options.base : item[0];
        var css = item[1];
        var media = item[2];
        var sourceMap = item[3];
        var part = {
          css: css,
          media: media,
          sourceMap: sourceMap
        };
        if (!newStyles[id]) {
          styles.push(newStyles[id] = {
            id: id,
            parts: [part]
          });
        } else {
          newStyles[id].parts.push(part);
        }
      }
      return styles;
    }
    function addStylesToDom(styles, options) {
      for (var i = 0; i < styles.length; i++) {
        var item = styles[i];
        var domStyle = stylesInDom[item.id];
        var j = 0;
        if (domStyle) {
          domStyle.refs++;
          for (; j < domStyle.parts.length; j++) {
            domStyle.parts[j](item.parts[j]);
          }
          for (; j < item.parts.length; j++) {
            domStyle.parts.push(addStyle(item.parts[j], options));
          }
        } else {
          var parts = [];
          for (; j < item.parts.length; j++) {
            parts.push(addStyle(item.parts[j], options));
          }
          stylesInDom[item.id] = {
            id: item.id,
            refs: 1,
            parts: parts
          };
        }
      }
    }
    function insertStyleElement(options) {
      var style = document.createElement('style');
      if (typeof options.attributes.nonce === 'undefined') {
        var nonce = true ? __webpack_require__.nc : undefined;
        if (nonce) {
          options.attributes.nonce = nonce;
        }
      }
      Object.keys(options.attributes).forEach(function (key) {
        style.setAttribute(key, options.attributes[key]);
      });
      if (typeof options.insert === 'function') {
        options.insert(style);
      } else {
        var target = getTarget(options.insert || 'head');
        if (!target) {
          throw new Error("Couldn't find a style target. This probably means that the value for the 'insert' parameter is invalid.");
        }
        target.appendChild(style);
      }
      return style;
    }
    function removeStyleElement(style) {
      // istanbul ignore if
      if (style.parentNode === null) {
        return false;
      }
      style.parentNode.removeChild(style);
    }
    /* istanbul ignore next  */

    var replaceText = function replaceText() {
      var textStore = [];
      return function replace(index, replacement) {
        textStore[index] = replacement;
        return textStore.filter(Boolean).join('\n');
      };
    }();
    function applyToSingletonTag(style, index, remove, obj) {
      var css = remove ? '' : obj.css; // For old IE

      /* istanbul ignore if  */

      if (style.styleSheet) {
        style.styleSheet.cssText = replaceText(index, css);
      } else {
        var cssNode = document.createTextNode(css);
        var childNodes = style.childNodes;
        if (childNodes[index]) {
          style.removeChild(childNodes[index]);
        }
        if (childNodes.length) {
          style.insertBefore(cssNode, childNodes[index]);
        } else {
          style.appendChild(cssNode);
        }
      }
    }
    function applyToTag(style, options, obj) {
      var css = obj.css;
      var media = obj.media;
      var sourceMap = obj.sourceMap;
      if (media) {
        style.setAttribute('media', media);
      }
      if (sourceMap && btoa) {
        css += "\n/*# sourceMappingURL=data:application/json;base64,".concat(btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))), " */");
      } // For old IE

      /* istanbul ignore if  */

      if (style.styleSheet) {
        style.styleSheet.cssText = css;
      } else {
        while (style.firstChild) {
          style.removeChild(style.firstChild);
        }
        style.appendChild(document.createTextNode(css));
      }
    }
    var singleton = null;
    var singletonCounter = 0;
    function addStyle(obj, options) {
      var style;
      var update;
      var remove;
      if (options.singleton) {
        var styleIndex = singletonCounter++;
        style = singleton || (singleton = insertStyleElement(options));
        update = applyToSingletonTag.bind(null, style, styleIndex, false);
        remove = applyToSingletonTag.bind(null, style, styleIndex, true);
      } else {
        style = insertStyleElement(options);
        update = applyToTag.bind(null, style, options);
        remove = function remove() {
          removeStyleElement(style);
        };
      }
      update(obj);
      return function updateStyle(newObj) {
        if (newObj) {
          if (newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap) {
            return;
          }
          update(obj = newObj);
        } else {
          remove();
        }
      };
    }
    module.exports = function (list, options) {
      options = options || {};
      options.attributes = typeof options.attributes === 'object' ? options.attributes : {}; // Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
      // tags it will allow on a page

      if (!options.singleton && typeof options.singleton !== 'boolean') {
        options.singleton = isOldIE();
      }
      var styles = listToStyles(list, options);
      addStylesToDom(styles, options);
      return function update(newList) {
        var mayRemove = [];
        for (var i = 0; i < styles.length; i++) {
          var item = styles[i];
          var domStyle = stylesInDom[item.id];
          if (domStyle) {
            domStyle.refs--;
            mayRemove.push(domStyle);
          }
        }
        if (newList) {
          var newStyles = listToStyles(newList, options);
          addStylesToDom(newStyles, options);
        }
        for (var _i = 0; _i < mayRemove.length; _i++) {
          var _domStyle = mayRemove[_i];
          if (_domStyle.refs === 0) {
            for (var j = 0; j < _domStyle.parts.length; j++) {
              _domStyle.parts[j]();
            }
            delete stylesInDom[_domStyle.id];
          }
        }
      };
    };

    /***/
  },

  /***/"./src/styles.css":
  /*!************************!*\
    !*** ./src/styles.css ***!
    \************************/
  /*! no static exports found */
  /***/
  function srcStylesCss(module, exports, __webpack_require__) {
    var content = __webpack_require__( /*! !../node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!../node_modules/postcss-loader/src??embedded!./styles.css */"./node_modules/@angular-devkit/build-angular/src/angular-cli-files/plugins/raw-css-loader.js!./node_modules/postcss-loader/src/index.js?!./src/styles.css");
    if (typeof content === 'string') {
      content = [[module.i, content, '']];
    }
    var options = {};
    options.insert = "head";
    options.singleton = false;
    var update = __webpack_require__( /*! ../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */"./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js")(content, options);
    if (content.locals) {
      module.exports = content.locals;
    }

    /***/
  },

  /***/3:
  /*!******************************!*\
    !*** multi ./src/styles.css ***!
    \******************************/
  /*! no static exports found */
  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__( /*! C:\smartfc\SMARTFC-Frontend\src\styles.css */"./src/styles.css");

    /***/
  }
}, [[3, "runtime"]]]);
//# sourceMappingURL=styles-es5.js.map